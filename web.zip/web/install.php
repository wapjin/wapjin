

<table  width="272" height="352" align="left">
		<form  action="lu.php" >
			
			
				<tr width="25" height="20">
						<td>����������</td><td><input name="user" width="25" height="20" type="text" id="user" ></td>
				</tr>
				<tr width="25" height="20">
						<td>�û�����</td><td><input name="nt" width="25" height="20" type="text" id="pass" ></td>
				</tr>
				<tr width="25" height="20">
						<td>���ݿ�����</td><td><input name="npp" width="25" height="20" type="text" id="pass" ></td>
				</tr>
				
				<tr width="25" height="20">
						<td>���ݿ����룺</td><td><input name="pass" width="25" height="20" type="text" id="pass1" ></td>
				</tr>
				
			
				<tr width="25" height="20">
						<td></td><td><input type="submit"  width="25" height="20" value="�ύ"  ></td>
				</tr>
		</form>
	</table> 
