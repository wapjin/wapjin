<meta content='width=device-width,initial-scale=1,user-scalable=no' name='viewport'>
<meta charset="UTF-8">  
﻿<?php

include "hr.php";
$name=$_POST['sname'];
$age=$_POST['sage'];
 
mysql_query ( "set names utf8" );
mysql_query("insert into liujin_ly(sname,sly) values('".$name."','".$age."')");

mysql_close($con);
echo '留言成功--<meta http-equiv=refresh content="1;url=./ly.php">';
?>