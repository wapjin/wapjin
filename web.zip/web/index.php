

<?php

include "./php/top.php";

$ru="user.php";	
	if(!file_exists($ru)){
		
		echo "<center><a href=install.php>------点击安装-----</a>";
		
	exit();
	}
include "hr.php";
include "ku.php";
echo '<title>'.$name.'</title>
<link rel="shortcut icon" href="img/1.ico" /> <html>';

echo '</head><body  align=center ><iframe width="350" scrolling="no" height="18" frameborder="0" allowtransparency="true" src="http://i.tianqi.com/index.php?c=code&id=1&color=%23&icon=1&py=luotian&wind=1&num=2&site=12"></iframe><br><br><marquee direction=left scrollamount=5> <font size=4 color=#FF0000>公告：'.$gao.'</font></marquee>';

$du=$_GET['do'];
if($du==null){
	echo "<div class=p > 开心一刻 </div><br><br>";
	$xiao = mysql_query("SELECT * FROM liujin_xiao order by id DESC limit 0,6 ");
	$tx=0;
	while($ut = mysql_fetch_array($xiao))
  {
$tx++;

echo " <a  href=xiao.php?ut=".$ut['id']."><div class=t1>".$ut['namet']."</div></a>" ;

  }
echo "<div class=p >  最新加入 </div><P><center><div class=t1>";
$result = mysql_query("SELECT * FROM liujin_num");

 $u= mysql_query("SELECT * FROM liujin_url order by id DESC limit 0,12 ");
 $t=0;
 while($urk = mysql_fetch_array($u))
  {
$t++;

echo "&nbsp&nbsp<a href=".$urk['url'].">".$urk['nim']."</a>" ;
if($t==6){
echo "</div><div class=t1>";
}
}
 
echo "</div></P></center><div  class=p > 分类大全 </div>";
while($row = mysql_fetch_array($result))
  {
  $p=$row['id'];
  $yu="SELECT * FROM liujin_url where uid=$p";
  $url= mysql_query($yu);
  $cc=mysql_num_rows($url);
  $t=rand(0,2);
   $yut="SELECT * FROM liujin_url where uid=$p order by id desc limit 0,5";
  $urlt= mysql_query($yut);
  
  echo "<div class=t1><a href=./?do=".$p.">".$row['name']."</a> |" ;
 while($ur = mysql_fetch_array($urlt))
  {


echo "&nbsp&nbsp<a href=".$ur['url'].">".$ur['nim']."</a>" ;
}
  echo "</p></div>";
  }
 

  echo "<br><div  class=p > 合作伙伴 </div><p><center><div class=t1>";
  echo $url_f.'</center>';
}else{
	$du=$_GET['do'];
	$k="SELECT * FROM liujin_num where id=$du";
	$gb = mysql_query($k);
	  
	
	 $urc = mysql_fetch_array($gb);
	 echo " <a href=index.php><<返回</a> <hr>";
	 $yu="SELECT * FROM liujin_url where uid=$du";
	 $url= mysql_query($yu);
	 $u=0;
	while($ur = mysql_fetch_array($url))
  {
$u++;

echo "&nbsp&nbsp<a href=".$ur['url'].">".$ur['name']."</a>" ;
if($u%3==0){
	
	echo "<hr>";
}
}
	
	
}
 include './php/wei.php';

   ?>
</body>
 