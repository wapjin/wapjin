<?php  require_once 'AipSpeech.php';// 你的 APPID AK SK

const APP_ID = '10583318';
const API_KEY = 'CMNj4Pe1gVgSKkv55T5cb0tq';
const SECRET_KEY = '03d9a4a93c72961c2ce4698904fb0b40';
$aipSpeech = new AipSpeech(APP_ID, API_KEY, SECRET_KEY);
$aipSpeech->asr(null, 'pcm', 16000, array(
    'url' => 'http://121.40.195.233/res/16_test.pcm',
    'callback' => 'http://wapjin.com',
));
?>
{
    "err_no": 0,
    "err_msg": "success.",
    "corpus_no": "15984125203285346378",
    "sn": "481D633F-73BA-726F-49EF-8659ACCC2F3D",
    "result": ["北京天气"]
}
// 失败返回
{
    "err_no": 2000,
    "err_msg": "data empty.",
    "sn": null
}