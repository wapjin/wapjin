﻿<meta content='width=device-width,initial-scale=1,user-scalable=no' name='viewport'>
<?php
include "./hr.php";
include "./php/top.php";
echo "<head><title>在线笑话</title></head>";
echo '<a href=./>< 返回</a><hr>';
$xiao = mysql_query("SELECT * FROM liujin_xiao where id=".$_GET['ut']);

	$ut = mysql_fetch_array($xiao);
  

echo "<p >标题：".$ut['namet']."</p><br><textarea style='font-size:15px; height:250px;   border: 0px ;width:100% ' readonly='true' >". $ut['rtxt']."</textarea>";






include "./php/wei.php";
?>