﻿<meta content='width=device-width,initial-scale=1,user-scalable=no' name='viewport'>
<?php
include "ku.php";
include "./php/top.php";


echo "<head><title>本站简介</title></head>";


echo '<a href=../><<返回</a><hr><textarea  readonly  rows="22" cols="50" readonly="true" >'.$jianjie.'</textarea>
</td></tr></table>






';
include "./php/wei.php";
?>