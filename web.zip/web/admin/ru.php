﻿<?php


$name = $_GET['url_name'];
if($name==null){
echo '录入失败！！<meta http-equiv="refresh" content="3;url=../">';
}else{





	$name = $_GET['url_name'];
$nim = $_GET['url_nim'];
$q=$GET['q'];
$url = $_GET['url_url'];
$key = $_GET['url_keys'];
$uid = $_GET['url_fid'];
include "./hr.php";
$u= mysql_query("SELECT * FROM liujin_url");

 
 while($urk = mysql_fetch_array($u))
  {
if($_GET['url_name']==$urk[name]){
echo "本网站已经被录取";exit();
}}
mysql_query("set names utf8");
mysql_query("INSERT INTO `liujin_url` (`name`, `uid`, `qq`, `url`, `ke`, `nim`) VALUES ('".$name."', '$uid', '".$q."', '$url', '".$key."', '".$nim."')");
echo '成功录入<meta http-equiv="refresh" content="0.2;url=../index.php">';


}



?>