<?php

include "./hr.php";
$b=$_GET['g'];

$l="delete from liujin_num where id=".$b;
  mysql_query($l);
  mysql_close($con);
  echo "删除成功？--<a href=./glfen.php>返回管理</a>";

?>