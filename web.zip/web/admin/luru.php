<?php
include "../php/top.php";
echo "<head><title>友链合作</title></head>";
include "./hr.php";

$sb = mysql_query("SELECT * FROM liujin_num");

echo '
<br>
<a href=../><<返回</a><hr>回链地址：wapjin.com
<form action="./ru.php" >
<p><input type="hidden" name="lan" maxlength="20" value="1"/>
<p><font color=#FF0000>友链录入自动审核</font></p><p>
首链简称(两字)<br><input type="text" name="url_nim" style="width:300px; height:40px; font-size:15px; " maxlength="2" value=""/></p><p>
网站名称(四字)<br><input type="text" style="width:300px; height:40px; font-size:15px; " name="url_name" maxlength="4" value="" /></p><p>
网站地址(回链)<br><input type="text" style="width:300px; height:40px; font-size:15px; " name="url_url" value=""/></p>
<p>

网站分类：<select title="鍒嗙被" name="url_fid" >';

while($r = mysql_fetch_array($sb)){
echo '
<option  value="'.$r['id'].'">'.$r['name'].'</option>
';}
echo '
</select></p><p>
<input type="submit" class="input_btn2" style="width:300px; height:30px; font-size:15px;" value="提交" /></p>



</form>

</body> 




';

include "../php/wei.php";

?>