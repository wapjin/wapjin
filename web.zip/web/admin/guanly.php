<meta content='width=device-width,initial-scale=1,user-scalable=no' name='viewport'>
<meta charset="UTF-8">  
﻿<?php
if($_COOKIE['cc']==666){
include "./hr.php";

mysql_query ( "set names utf8" );
$u = mysql_query("SELECT * FROM liujin_ly");
echo '<head><title>留言管理</title></head><br><a href=./admin.php>返 回</a><hr color=red><p  >';
while($urk = mysql_fetch_array($u))
  {
  $a++;
  echo $a."、<a href=./lyl.php?g=".$urk['id'].">".$urk['sname']."</a><br>";
  
  
  
  
}
echo '</p>';
}
?>