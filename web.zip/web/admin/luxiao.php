﻿<?php
if($_COOKIE['cc']==666){
echo "
<head><title>笑话录入</title></head>
<table border=0 cellspacing=0 cellpadding=0 align=center width=300>
<tr>
<td ><div style='background:#C0C0C0; padding-bottom:7px;'><a href=./admin.php>返 回</a></div></td></tr><tr><td><br>
<form method=post action=gx.php><p>标题:<input type=text name='sname'><br> <p>内容:<textarea type=text name=sage></textarea></P></td></tr>
<tr><td>&nbsp &nbsp <input type=submit value=' 提 交 '></font><td></tr></table></form>";


}



?>