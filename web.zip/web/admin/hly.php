<meta content='width=device-width,initial-scale=1,user-scalable=no' name='viewport'>
<meta charset="UTF-8">  
<?php

include "./hr.php";
$b=$_GET['p'];
 $f= $_GET['d'];
if($f==null){
?>
<form  action=./hly.php >
<input type=hidden name=p  value="<?php echo $b; ?>">
<p><textarea type=text name=d style='width:300px; height:200px; font-size:15px; '></textarea></P>
<input type=submit value=' 提 交 '  style='width:300px; height:30px; font-size:15px;'></font></form>
<?php
}else{
$sql = "UPDATE liujin_ly SET hly='".$f."' where id=".$b;  

if(mysql_query($sql)){
echo "回复成功";
}
mysql_close();
 }
  echo "-<a href=./lyl.php?g=".$b.">返回后台</a>";

?>
