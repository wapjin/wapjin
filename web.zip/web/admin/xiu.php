<?php
$p = $_GET['lan'];
$name = $_GET['url_name'];
$nim = $_GET['url_nim'];
$q=$GET['q'];
$url = $_GET['url_url'];
$key = $_GET['url_keys'];
$uid = $_GET['url_fid'];
include "./hr.php";
	mysql_query ( "set names utf8" );
 $jia="update liujin_url set qq='".$q."',nim='".$nim."',url='".$url."',ke='".$key."',uid='".$uid."' where id=".$p;
mysql_query($jia);
mysql_close($con);
  echo "修改成功？<br><a href=./admin.php>返回后台</a>";


?>