<meta content='width=device-width,initial-scale=1,user-scalable=no' name='viewport'>
<meta charset="UTF-8"> 
<?php
if($_COOKIE['cc']==666){
include "./hr.php";

mysql_query ( "set names utf8" );
$u = mysql_query("SELECT * FROM liujin_num limit 0,20");
echo '<head><title>分类管理</title></head>
<table border=0 cellspacing=0 cellpadding=0 align=center width=300><tr><td >';
while($urk = mysql_fetch_array($u))
  {
  
  echo $urk['name']."----<a href=./su.php?g=".$urk['id'].">删除</a><hr>";
  
  
  
  
}
echo '<br><a href=./admin.php>返回后台</a><td></tr></table>';
}
?>