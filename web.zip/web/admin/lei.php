﻿<?php


$name = $_GET['lan'];


if($name==null){
echo '录入失败！！<meta http-equiv="refresh" content="3;url=../">';
}else{
	include "./hr.php";
	$n=$_GET['lan'];
	//mysql_query("set names gb2312");
mysql_query("INSERT INTO `liujin_num` (`name`) VALUES ('".$n."')");
echo '成功录入<meta http-equiv="refresh" content="3;url=./admin.php">';}
?>