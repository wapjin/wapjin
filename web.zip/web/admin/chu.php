﻿<?php

$pa=$_GET['mid'];
include "../ku.php";
if($pa==$pass){

echo '<meta http-equiv="refresh" content="0.1;url=./cc.php">';

}else{

echo '密码错误请重新输入！！<meta http-equiv="refresh" content="2;url=./">';


}



?>