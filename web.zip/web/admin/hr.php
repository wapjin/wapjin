﻿
<?php
include "user.php";
$con=mysql_connect("$host","$usert","$passu") or die("连接数据库失败");
mysql_select_db($npp);
mysql_query("set names utf8");
?>
