<meta content='width=device-width,initial-scale=1,user-scalable=no' name='viewport'>
<meta charset="UTF-8">  
<?php

include "./hr.php";
$s=$_GET['g'];
mysql_query ( "set names utf8" );
$c="SELECT * FROM liujin_ly where id=".$s;
$u = mysql_query($c);
 $urk = mysql_fetch_array($u);
echo '<head><title>留言类容</title></head><br><a href=./admin.php>返 回</a><hr color=red><table ><th>内容</th><th>回复</th><th>操作</th>';

 

	  
	 
  
  
  echo "<tr Height=70px ><td width=100px>".$urk['sly']."</td><td width=100px>".$urk['hly']."</td><td width=100px>[<a href=./suly.php?p=".$s.">删除</a>]|[<a href=./hly.php?p=".$s.">回复</a>]</td></tr>";
  

echo '</table>';


?>