﻿<meta content='width=device-width,initial-scale=1,user-scalable=no' name='viewport'>
<?php
if($_COOKIE['cc']==666){
echo "<head><title>后台管理</title></head>";

echo "
<table align=center ><tr><td  align=center ><h4>---后台管理---</h4></td></tr><tr><td>
<p><a href=./gai.php>网站配置</a> |  <a href=./fen.php>添加分类</a></p>
<p><a href=./luru.php>网站收录</a> |  <a href=./guanly.php>留言管理</a></p>
<p><a href=./glurl.php>友链管理</a> |  <a href=./glfen.php>分类管理</a> </p>
<P><a href=./xouxiao.php>笑话管理</a> |  <a href=./luxiao.php>笑话录入</a> <p><p> <a href=../php/ru.php>笔记录取</a> | <a href=../php/del.php>删除笔记</a></P>
<p> <a href=../>首页</a></P>
</td></tr></table>



";
}

?>