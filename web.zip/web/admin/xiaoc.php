<?php

include "./hr.php";

$b=$_GET['ut'];

$l="delete from liujin_xiao where id=".$b;
  mysql_query($l);
  mysql_close($con);
  echo "删除成功？--<a href=./xouxiao.php>返回管理</a>";
?>