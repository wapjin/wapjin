<?php

include "./hr.php";
$b=$_GET['p'];
  
$sql = "delete from liujin_ly where id=".$b;

$result = mysql_query($sql);

if(mysql_affected_rows() > 0) {

echo “删除成功”;

}

mysql_close();
 
  echo "-<a href=./admin.php>返回后台</a>";

?>