﻿
<meta content='width=device-width,initial-scale=1,user-scalable=no' name='viewport'>

<?php

echo '
<head><title>后台登陆</title></head>
<table align=center ><tr><td>
<form action="./chu.php" >

请输入密码：<br><input type="password" name="mid">&nbsp;&nbsp;
<input name="" type="submit" value="登录" />



</form>

</td></tr></table>

';

?>