﻿<meta content='width=device-width,initial-scale=1,user-scalable=no' name='viewport'>
<?php
if($_COOKIE['cc']==666){
$v=$_GET['g'];
$b=$_GET['p'];
$ni=$_GET['url_ni'];
include "./hr.php";
echo '<head><title>友链管理</title></head>
<table border=0 cellspacing=0 cellpadding=0 align=center width=300><tr><td ><a href=./admin.php>返回后台</a><hr>';
if($v==null){

	echo'<form action="./glurl.php" ><p>
名称：<input type="text" name="url_ni" maxlength="8" value=""/></p><p>
<input type="submit" class="input_btn2" value="搜 索" /></p>';
if($ni<>null){
	mysql_query ( "set names utf8" );
	$yy="SELECT * FROM liujin_url where nim='".$ni."'";
$u= mysql_query($yy);
$urk = mysql_fetch_array($u);
  
  
  echo $urk['name']."---<a href=./glurl.php?g=".$urk['id'].">更改</a>|<a href=./shuan.php?p=".$urk['id'].">删除</a><hr>";
  
  
}else{
	echo "搜索为空";
	
}
  


}

	
	else if($v<>null){
	mysql_query ( "set names utf8" );
	$u= mysql_query("SELECT * FROM liujin_url where id=$v ");
$urk = mysql_fetch_array($u);
	$sb = mysql_query("SELECT * FROM liujin_num");
	echo '
<table align=center ><tr><td><h2>友链更改</h2></td></tr><tr><td>
<form action="./xiu.php" >
<p><input type="hidden" name="lan" maxlength="20" value="'.$urk[id].'"/>
联系QQ：<input type="text" name="q" maxlength="20" value="'.$urk['qq'].'"/></p><p>
首链简称(两字)<input type="text" name="url_nim" maxlength="8" value="'.$urk['nim'].'"/></p><p>
网站名称(四字)<input type="text" name="url_name" maxlength="10" value="'.$urk['name'].'" /></p><p>
网站地址：(回链)<input type="text" name="url_url" value="'.$urk['url'].'"/></p><p>
关键字：<input type="text" name="url_keys" maxlength="30" value="'.$urk['ke'].'" /></p><p>

网站分类：<select title="鍒嗙被" name="url_fid" >';

while($r = mysql_fetch_array($sb)){
echo '
<option  value="'.$r['id'].'">'.$r['name'].'</option>
';}
echo '
</select></p><p>
<input type="submit" class="input_btn2" value="修改" /></p>



</form>
<a href=./glurl.php>返回管理</a>
</td></tr></table>';
	

	
	
	
}

  
	

echo '<br><td></tr></table>';

}
?>