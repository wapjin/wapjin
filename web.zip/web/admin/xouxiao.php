﻿<meta content='width=device-width,initial-scale=1,user-scalable=no' name='viewport'>
<?php
include "hr.php";

echo "<table border=0 cellspacing=0 align=center cellpadding=0  width=300><tr>
<a href=./admin.php>返 回</a><hr color=red>";
$xiao = mysql_query("SELECT * FROM liujin_xiao order by id DESC ");
	$tx=0;
	while($ut = mysql_fetch_array($xiao))
  {
$tx++;

echo "<tr><td >".$tx."、&nbsp&nbsp".$ut['namet']." </td ><td ><a  href=xiaoc.php?ut=".$ut['id'].">删 除</a></td ></tr>" ;

  }
echo "</table>";


?>