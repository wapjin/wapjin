<?php

include "hr.php";
$name=$_POST['sname'];$age=$_POST['sage'];
 

mysql_query("insert into liujin_xiao(namet,rtxt) values('".$name."','".$age."')");

mysql_close($con);
echo '录入成功--<meta http-equiv=refresh content="2;url=./admin.php">';



?>