﻿
<meta content='width=device-width,initial-scale=1,user-scalable=no' name='viewport'>
<?php
if($_COOKIE['cc']==666){
	
include "../ku.php";


echo "<html><head><title>网站配置</title></head><body>";

echo '

<h2>配置修改</h2>
<hr>
<form action="./gai.php"  >
<p>
<input type="hidden" name="do" maxlength="20" value="1"/>
公告：<textarea name=gao style="width:100%; height:300px; font-size:15px;" > '.$gao.'</textarea></p><p>
站名：<input type="text" name="namel" maxlength="8" value="'.$name.'"/></p><p>
固链：<textarea name=url style="width:100%; height:300px; font-size:15px;" >'.$url_f.'</textarea></p>
<p>
简介：<textarea name=jianjie style="width:100%; height:300px; font-size:15px;" >'.$jianjie.'</textarea></p>
底部：<textarea name=dt style="width:100%; height:300px; font-size:15px;" >'.$dt.'</textarea></p><p>
密码：<input type="text" name="passd" maxlength="10" value="'.$pass.'" /></p><p>

<p>
<input type="submit" class="input_btn2" value="提交" /></p>



</form>
<a href=./admin.php>返回后台</a>

';
$do=$_GET['do'];
if($do=="1"){

$det=$_GET['dt']; $jian=$_GET['jianjie'];$ga=$_GET['gao'];$na=$_GET['namel'];$pas=$_GET['passd'];$url=$_GET['url'];

$ad='<?php

$dt="'.$det.'";$jianjie="'.$jian.'"; $gao="'.$ga.'";$name="'.$na.'";$pass="'.$pas.'";$url_f="'.$url.'";
?>';

$fp=fopen("../ku.php","w");
fwrite($fp,$ad);
fclose($fp);
echo "修改成功";




}
}
?>