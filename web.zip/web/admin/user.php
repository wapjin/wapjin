
<?php

$host="localhost";
$usert="";
$passu="";
$npp="";


?>