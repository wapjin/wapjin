﻿<meta content='width=device-width,initial-scale=1,user-scalable=no' name='viewport'>
<?php 
if($_COOKIE['cc']==666){
echo '

<table align=center ><tr><td><h2>添加分类</h2></td></tr><tr><td>
<form action="./lei.php" >
<p>
输入分类名：<input type="text" name="lan" maxlength="20" /></p>
<p>
<input type="submit" class="input_btn2" value="提交" /></p>



</form>
<a href=./admin.php>返回后台</a>
</td></tr></table>';

}

?>