<?php  
include_once "conn.php";
include_once "top.php";
if($_GET['idc']!=null){
$sql = "DELETE FROM php WHERE id = ".$_GET['idc'];

$result = mysql_query($sql);

if(mysql_affected_rows() > 0) {

echo “删除成功”;
Echo '  <meta http-equiv="refresh" content="1;url=./">';

}}else{ 

Echo  '<form  action="c2.php"  method="post" >
标题 :<br>
<input type="text" style="width:200px; height:30px"; name="s" value="">
 <input type=hidden name=del value="1">
&nbsp;<input type="submit" value="查 询">
</form>';

}



 ?>