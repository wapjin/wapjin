<?php 

$t1 = microtime(true);

echo '
<html>  
<head>  
<meta name="description" content="学习PHP的平台">           
<meta name="keywords" content="php之家，学习PHP的平台">           
<meta name="author" content="jinjin">                      
<meta charset="UTF-8">  
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />
    <meta name="format-detection" content="telphone=no, email=no" />
  <title>忆梦导航</title>
<link rel="shortcut icon" href="../php/img/1.ico" />
<link rel="stylesheet" type="text/css" href="../php/css.css">                                       
</head>  
<body>
<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?2ce92fe3f7591ea0c18517ab9a1c7fd9";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>
  ';
$wr= $_SERVER["HTTP_USER_AGENT"];
if(substr($wr,13,1)=="W"){
echo "<h2 align=center>请用手机访问</h2>";
exit();
}
if($_GET['t']==1||$_GET['t']==null){
$wt="梦中的婚礼";
$w="bb.mp3";
}
if($_GET['t']==2){
$w="aa.mp3";
$wt="胡彦斌 - 月光";
}
echo '<form action="../php/c2.php" method="post"><div class=top ><a href=./><img id="gg" src="../php/img/top.jpg"/> </a><div  class=top1><input type="text" name="s" id="t" placeholder="请输入搜索内容" >
       
  </form> </div><div class = top3><ul class="nav">
        <li class="drop-down"><a href="#"><h2>≡</h2></a>
            <ul class="drop-down-content">
                <li><a href="../">首 页</a></li>
                <li><a href="../php/url.php">查看源码</a></li>
                <li><a href="../php">个人笔记</a></li>
<li><a href="../php/r.php">在线音乐</a></li>
<li><a href="../admin/luru.php">网站收录</a></li>
<li><a href="../ly.php">在线留言</a></li>
<li><a href="../jianjie.php">关于本站</a></li>
            </ul>
            </li>
    </ul></div></div><br><br><br>';

?>
  