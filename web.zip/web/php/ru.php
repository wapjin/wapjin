<?php
include_once "top.php";
include_once "conn.php";
@header('Content-type: text/html;charset=UTF-8');
$userId=$_POST['wen'];

if($userId!=null){

$userId= htmlspecialchars($_POST['wen']);
$userName= htmlspecialchars($_POST['title']);
mysql_query("set names utf8");
mysql_query('INSERT INTO php (wen, title) VALUES ("'.$userId.'", "'.$userName.'")');
mysql_close($conn);
echo '成功录入<meta http-equiv="refresh" content="0.5;url=./">';
}else{





?><a href="./"> <<返回</a><hr width=360px align=left>

<form  method = 'post' >
 标题:
<input type="text" name="title" style="width:300px; height:30px; font-size:15px; ">
<p>
<textarea name="wen" style="width:350px; height:300px; font-size:15px; "> </textarea></p>
 <p>
<input type="submit" value="提 交" style="width:350px; height:30px; font-size:15px; ">
</p>
</form> 
<?php  }





include_once "wei.php"; ?>