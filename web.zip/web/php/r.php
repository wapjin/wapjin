<meta charset="UTF-8">  
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;" name="viewport" /><?php
include './top.php';
echo '在线音乐<hr color=#40E0D0>曲名：'.$wt.'<br><audio id="bgmMusic" src="../img/'.$w.'" autoplay="autoplay" loop="loop" controls="controls" type="audio/mp3"></audio><hr color=#40E0D0><h4 align=left >列表</h4><hr><left><a href=./r.php?t=1>梦中的婚礼</a><hr><a href=./r.php?t=2>胡彦斌 - 月光</a><hr></left><p>';
	include'./wei.php';
?>