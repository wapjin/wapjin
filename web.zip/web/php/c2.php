<?php

include_once "top.php";
include_once "conn.php";
mysql_query("set names utf8");
$r=$_POST['s'];


echo '<a href="./"><<返回</a><hr width=360px align=left>搜索结果:';
$result = mysql_query("SELECT * FROM php where title like '%".$r."%'");
$row=mysql_fetch_array($result);
 $result1 = mysql_query("SELECT * FROM liujin_url where name like '%".$r."%'");
$row1 = mysql_fetch_array($result1);
if($row['id']==null ||$r==null){
 $result1 = mysql_query("SELECT * FROM liujin_url where name like '%".$r."%'");
$row1 = mysql_fetch_array($result1);
if($row1['id']!=null){


echo '友链<hr color=red><a href="'.$row1['url'].'"><div class="sb" >'.$row1['name'].'</div></a><br>';
}else{
	  echo "<p align=center>暂无数据！</p>";
}
}else{
$result = mysql_query("SELECT * FROM php where title like '%".$r."%'");
while($row = mysql_fetch_array($result))
  {
	  
echo '<a href="look.php?do='.$row['id'].'"><div class="sb" >'.$row['title'].'</div></a><br>';
 if($_POST['del']=="1"){
echo'<a href=del.php?idc='.$row['id'].'>删除</a>';
}
  }

mysql_close($conn);
	  }
	

include_once "wei.php";

?>