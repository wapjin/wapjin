<?php
include_once "top.php";
include_once "c1.php";
include_once "wei.php";
?>