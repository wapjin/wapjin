<div class=ac> </div>

<div class=cc>
<?php
echo $dt;
$t = time();
echo date("Y-m-d  H:i", $t);
$t2 = microtime(true);
echo ',耗时'.round($t2-$t1,3).'秒-IP:';
$ip = $_SERVER["REMOTE_ADDR"];
echo $ip;

echo "</div></body>  </html>  ";



?>