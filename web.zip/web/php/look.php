<?php
include_once "top.php";
include_once "conn.php";
mysql_query("set names utf8");
$r=$_GET['do'];
$result = mysql_query("SELECT * FROM php where id='".$r."'");

$row = mysql_fetch_array($result);
$result1 = mysql_query("SELECT * FROM php where id='".($r-1)."'");

$row1 = mysql_fetch_array($result1);
$result2 = mysql_query("SELECT * FROM php where id='".($r+1)."'");

$row2 = mysql_fetch_array($result2);

echo '<a href="./"> <<返回</a><hr  align=left><p align=left>标题：'.$row['title'].'</p><p><textarea style="width:100%; height:300px; font-size:15px; border: 0px; "  readonly>'.$row['wen'].'</textarea></p>';

 echo '上一条：<a href="./look.php?do='.$row2['id'].'">'.$row2['title'].'</a><p>';
echo '下一条：<a href="./look.php?do='.$row1['id'].'">'.$row1['title'].'</a></p>';
mysql_close($conn);


include_once "wei.php";



?>