<meta charset="UTF-8">  
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;" name="viewport" />

<?php

$t=$_GET['tr'];

if($t!=null){    

$myfile = fopen($t, "w+");
echo  '成功生成文件—'.$t;
echo '<a href=./><<返回列表</a>';
}else{
echo '<a href=./><<返回列表</a>';
?>

<form action="" method="get">
   文件名：<input type="text" style="width:300px; height:30px; font-size:15px; " value= <?php echo getcwd(); ?> name="tr"/><p>
   <input type="submit" value="提交" style="width:300px; height:30px; font-size:15px; "></p>
</form>
          


<?php
}

?>     