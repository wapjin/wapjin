<?php
include_once "conn.php";
mysql_query("set names utf8");
$result = mysql_query("SELECT * FROM php  order by id desc ");
echo '  <b align=right>笔记列表</b><hr color=red> ' ;
while($row = mysql_fetch_array($result))
  {
echo ' <a  class=sb href="look.php?do='.$row['id'].'">'.$row['title'].'</a> ';

  }

mysql_close($conn);
?>