<?php
include_once "top.php";
echo '<a href="./"><<返回</a><hr width=360px align=left>';
$url=$_GET['url'];
if($url!=null){
$lines_array = file($url);
 ?> 
<textarea  style="width:80%; height:300px"; ><?php foreach($lines_array as $a){ echo $a ;} echo ' </textarea>'; }else{?>
<form >
网 址:<br>
<input type="text" style="width:200px; height:30px"; name="url" value="http://">

&nbsp;<input type="submit" value="查 询">
</form>
<?php }
include_once "wei.php";
 ?>