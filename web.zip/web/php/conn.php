﻿<?php

    $host="localhost";
$usert="wapjin00";
$passu="jin5200";
$npp="wapjin00";

    $conn=mysql_connect("$host","$usert","$passu") or die("连接数据库失败");
mysql_select_db($npp);

 ?>