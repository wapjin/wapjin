<?php

$user=$_GET['user'];$nt=$_GET['nt'];$pass=$_GET['pass'];$npp=$_GET['npp'];
if($user==null){
	
	echo "������";
	
	
}else{
$tyy='
<?php

$host="'.$user.'";
$usert="'.$nt.'";
$passu="'.$pass.'";
$npp="'.$npp.'";


?>';
$ty='
<?php

$host="'.$user.'";
$usert="'.$nt.'";
$passu="'.$pass.'";
$npp="'.$npp.'";


?>';
$ph=fopen("./admin/user.php","w");
fwrite($ph,$ty);
fclose($ph);

$pp=fopen("user.php","w");
fwrite($pp,$tyy);
fclose($pp);
echo "<center>------�����ύ�ɹ���<a href=?do=2>����������ݱ�</a>------";
exit();
}


if($_GET['do']==2){
	
	include 'hr.php';

	$ku="create table shi
	(
	id int not null auto_increment,
	primary key(id),
	
        name char(255),
		vsts varchar(255),
        shijian datetime(0),
	
	)
	";
	$kin="create table liujin_num
	(
	
	
	name varchar(10),
	
	id  int not null auto_increment,
	primary key(id)
	)
	";
	$ki="create table liujin_ly
	(
	
	
	sname varchar(5),
	sly varchar(50),
	id  int not null auto_increment,
	primary key(id)
	)
	";
	$kiu="create table liujin_xiao
	(
	
	
	namet varchar(10),
	rtxt longtext(5000),
	id  int not null auto_increment,
	primary key(id)
	)
	";
	mysql_query($ki);
	mysql_query($kiu);
	mysql_query($ku);
	mysql_query($kin);
	mysql_close($con);
	echo "<center>����ɹ���<a href=./admin/gai.php>��վ����</a>";
}else{
	
	
	echo "ʧ��";
	
}
?>