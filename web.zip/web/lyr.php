<meta content='width=device-width,initial-scale=1,user-scalable=no' name='viewport'>
<meta charset="UTF-8">  
<?php

include "./hr.php";
$s=$_GET['g'];
mysql_query ( "set names utf8" );
$c="SELECT * FROM liujin_ly where id=".$s;
$u = mysql_query($c);
 $urk = mysql_fetch_array($u);
echo '<head><title>留言类容</title></head><br><a href=./ly.php>返 回</a><hr color=red><table align=center>';

  echo "<tr Height=60px ><td >".$urk['sly']."</td></tr><tr><td><br>回复：";
if($urk['hly']==null){
echo "等待回复！";
}else{
echo $urk['hly'];
}

  

echo '</td></tr></table>';


?>
