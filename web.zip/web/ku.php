<?php

$dt="域名：wapjin.com.<font color=red >忆梦技术支持</font><br>


";$jianjie="本站建2017.8.18 ，此网站用于开发测试。
站长QQ:1045833538
邮箱：1045833538@qq.com"; $gao="     欢迎来到忆梦导航—wapjin.com";$name="忆梦导航";$pass="";$url_f="<a href=http://q18idc.com>18IDC</a>  <a href=http://75wz.net/hk.asp?xg=wapjin>七五</a> <a href=https://www.52liming.com/ >小鸣的微笔记</a>";
?>