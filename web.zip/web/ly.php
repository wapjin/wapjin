<meta content='width=device-width,initial-scale=1,user-scalable=no' name='viewport'>
<?php 
include"./php/top.php";
include "./hr.php";
echo "
<head><title>留言列表</title></head>";
echo "<a href=./><<返 回</a> <hr color=red><br><center><a href=./ly.php?do=1>[写留言]</a></center><br><p  >";
if($_GET['do']!=1){

mysql_query ( "set names utf8" );
$u = mysql_query("SELECT * FROM liujin_ly");

while($urk = mysql_fetch_array($u))
  {
  $r++;
  echo $r."、<a href=./lyr.php?g=".$urk['id'].">".$urk['sname']."</a><hr height=1px >";
  
  
  
  
}
echo '</p>';
}else{
echo "<form method=post action=lyp.php><p>昵称:<input type=text name='sname' style='width:260px; height:30px; font-size:15px;'><br> <p><textarea type=text name=sage style='width:300px; height:200px; font-size:15px; '></textarea></P><input type=submit value=' 提 交 '  style='width:300px; height:30px; font-size:15px;'></font></form>";
}
include"./php/wei.php";
?>